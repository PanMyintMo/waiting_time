package com.pan.waitingtime.model

data class Patient(var position : Int)
