package com.pan.waitingtime.model

data class Doctor(var name : String, var time : Int)
